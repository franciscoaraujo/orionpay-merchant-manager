'use client';

import React from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  AreaChart, 
  Area 
} from 'recharts';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Percent, 
  ArrowUpRight, 
  CreditCard,
  Users
} from 'lucide-react';
import { cn } from '@/lib/utils';

const BrandIcon = ({ brand }: { brand: string }) => {
  const isVisa = brand.toLowerCase().includes('visa');
  const isMaster = brand.toLowerCase().includes('master');
  const isElo = brand.toLowerCase().includes('elo');
  const isAmex = brand.toLowerCase().includes('amex');

  return (
    <div className="flex items-center gap-2">
      <div className="flex -space-x-1">
        {isVisa && <div className="w-5 h-3 bg-[#1A1F71] rounded-xs flex items-center justify-center text-[5px] text-white font-bold italic">VISA</div>}
        {isMaster && <div className="w-5 h-3 bg-[#EB001B] rounded-xs flex items-center justify-center text-[5px] text-white font-bold italic">MC</div>}
        {isElo && <div className="w-5 h-3 bg-[#00AEEF] rounded-xs flex items-center justify-center text-[5px] text-white font-bold italic">ELO</div>}
        {isAmex && <div className="w-5 h-3 bg-[#007BC1] rounded-xs flex items-center justify-center text-[5px] text-white font-bold italic">AMEX</div>}
      </div>
      <span className="font-bold text-primary">{brand}</span>
    </div>
  );
};

const data = [
  { name: '08:00', sales: 4000, yesterday: 2400 },
  { name: '10:00', sales: 3000, yesterday: 1398 },
  { name: '12:00', sales: 2000, yesterday: 9800 },
  { name: '14:00', sales: 2780, yesterday: 3908 },
  { name: '16:00', sales: 1890, yesterday: 4800 },
  { name: '18:00', sales: 2390, yesterday: 3800 },
  { name: '20:00', sales: 3490, yesterday: 4300 },
];

const kpis = [
  { label: 'Total Processado (TPV)', value: 'R$ 128.450,00', change: 12.5, trend: 'up', icon: DollarSign },
  { label: 'Receita Líquida (MDR)', value: 'R$ 3.850,20', change: 8.2, trend: 'up', icon: Percent },
  { label: 'Taxa de Aprovação', value: '94.8%', change: 2.1, trend: 'up', icon: ArrowUpRight },
  { label: 'Transações Ativas', value: '1.240', change: -1.5, trend: 'down', icon: CreditCard },
];

export default function DashboardPage() {
  return (
    <MainLayout>
      <div className="space-y-8">
        {/* KPI Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {kpis.map((kpi) => (
            <div key={kpi.label} className="bg-card p-6 rounded-2xl border border-border shadow-sm hover:shadow-md transition-shadow group">
              <div className="flex justify-between items-start mb-4">
                <div className="p-2 bg-muted rounded-xl group-hover:bg-primary/5 transition-colors">
                  <kpi.icon size={20} className="text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
                <div className={cn(
                  "flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-full",
                  kpi.trend === 'up' ? "bg-emerald-100 text-emerald-800" : "bg-rose-100 text-rose-800"
                )}>
                  {kpi.trend === 'up' ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                  {Math.abs(kpi.change)}%
                </div>
              </div>
              <div className="space-y-1">
                <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest block">{kpi.label}</span>
                <span className="text-2xl font-bold text-primary tracking-tight">{kpi.value}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-card p-6 rounded-2xl border border-border shadow-sm">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h3 className="text-lg font-bold text-primary">Tendência de Vendas</h3>
                <p className="text-xs text-muted-foreground font-medium">Comparativo Hoje vs Ontem em tempo real</p>
              </div>
              <div className="flex items-center gap-4 text-xs font-bold uppercase tracking-widest">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-accent" />
                  <span className="text-primary">Hoje</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-muted-foreground/30" />
                  <span className="text-muted-foreground">Ontem</span>
                </div>
              </div>
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                  <defs>
                    <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 10, fill: '#64748b', fontWeight: 'bold' }} 
                  />
                  <YAxis 
                    hide 
                  />
                  <Tooltip 
                    contentStyle={{ 
                      borderRadius: '12px', 
                      border: '1px solid #e2e8f0',
                      boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                      fontSize: '12px',
                      fontWeight: 'bold'
                    }} 
                  />
                  <Area 
                    type="monotone" 
                    dataKey="sales" 
                    stroke="#10b981" 
                    strokeWidth={3}
                    fillOpacity={1} 
                    fill="url(#colorSales)" 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="yesterday" 
                    stroke="#94a3b8" 
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={false}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Volume por Bandeira */}
          <div className="bg-card p-6 rounded-2xl border border-border shadow-sm">
            <h3 className="text-lg font-bold text-primary mb-6">Volume por Bandeira</h3>
            <div className="space-y-6">
              {[
                { brand: 'Visa', value: 'R$ 54.200,00', percentage: 42, color: 'bg-primary' },
                { brand: 'Mastercard', value: 'R$ 48.900,00', percentage: 38, color: 'bg-secondary' },
                { brand: 'Elo', value: 'R$ 15.450,00', percentage: 12, color: 'bg-accent' },
                { brand: 'Outros', value: 'R$ 9.900,00', percentage: 8, color: 'bg-muted-foreground/30' },
              ].map((item) => (
                <div key={item.brand} className="space-y-2">
                  <div className="flex justify-between items-center text-sm">
                    <BrandIcon brand={item.brand} />
                    <span className="text-muted-foreground font-medium">{item.value}</span>
                  </div>
                  <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                    <div 
                      className={cn("h-full rounded-full transition-all duration-1000", item.color)} 
                      style={{ width: `${item.percentage}%` }} 
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
