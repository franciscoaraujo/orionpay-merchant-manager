'use client';

import React, { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { TransactionTable } from '@/components/dashboard/TransactionTable';
import { TransactionDrawer } from '@/components/dashboard/TransactionDrawer';
import { Transaction, TransactionEvent } from '@/types';
import { useQuery } from '@tanstack/react-query';
import { mockTransactions, mockEvents } from '@/services/api';

export default function TransactionsPage() {
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  // Fetch transactions using React Query (Mocked for now)
  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ['transactions'],
    queryFn: async () => {
      // In a real app: const { data } = await api.get('/transactions'); return data;
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate delay
      return mockTransactions as Transaction[];
    },
  });

  // Fetch transaction events (Mocked for now)
  const { data: events = [], isLoading: isLoadingEvents } = useQuery({
    queryKey: ['transaction-events', selectedTransaction?.id],
    queryFn: async () => {
      if (!selectedTransaction) return [];
      // In a real app: const { data } = await api.get(`/transactions/${selectedTransaction.id}/events`); return data;
      await new Promise(resolve => setTimeout(resolve, 500)); // Simulate delay
      return mockEvents.filter(e => e.transaction_id === selectedTransaction.id) as TransactionEvent[];
    },
    enabled: !!selectedTransaction,
  });

  const handleSelectTransaction = (transaction: Transaction) => {
    setSelectedTransaction(transaction);
    setIsDrawerOpen(true);
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-end">
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-primary tracking-tight">Extrato de Transações</h2>
            <p className="text-muted-foreground text-sm">Acompanhe e gerencie as operações em tempo real.</p>
          </div>
          <div className="text-right">
            <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest block">Saldo Disponível</span>
            <span className="text-2xl font-bold text-accent tracking-tighter">R$ 45.230,80</span>
          </div>
        </div>

        <TransactionTable 
          transactions={transactions} 
          isLoading={isLoading} 
          onSelectTransaction={handleSelectTransaction}
        />

        <TransactionDrawer 
          transaction={selectedTransaction}
          events={events}
          isOpen={isDrawerOpen}
          onClose={() => setIsDrawerOpen(false)}
          isLoadingEvents={isLoadingEvents}
        />
      </div>
    </MainLayout>
  );
}
